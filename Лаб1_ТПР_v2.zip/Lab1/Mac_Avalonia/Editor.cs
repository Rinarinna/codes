using System;
using System.Collections.ObjectModel;

namespace LabFio
{
    /*
     * Лабораторная работа №1. Автоматизация ввода списков «на лету» по шаблону.
     *
     * Класс Editor - ЛОГИКА редактирования строки ввода, отдельно от окна.
     * Окно (MainWindow) при каждом нажатии клавиши передаёт сюда текст строки
     * и выделение, вызывает Press(клавиша) и показывает результат.
     * Благодаря этому логику можно тестировать без окна (см. Tests.cs).
     *
     * Машинистка печатает как удобно: без точек, в любом регистре, с лишними пробелами.
     * Программа приводит строку к формату, заданному ШАБЛОНОМ:
     *   шаблон "Аа А.А.":  "новиков-прибой ас"  ->  "Новиков-Прибой А.С."
     *
     * Кодирование шаблона (анализируется n-ная позиция шаблона):
     *   прописная буква (А)  - одна прописная буква;
     *   строчная буква  (а)  - остальные буквы слова, строчные, сколько угодно.
     *                          В слове допускается ОДИН дефис (двойная фамилия),
     *                          буква после дефиса - прописная;
     *   алфавит буквы шаблона (кириллица / латиница) задаёт алфавит вводимых букв
     *                          на этой позиции; буквы другого алфавита игнорируются;
     *   любой другой символ  - разделитель:
     *        после прописной (А.) - ставится программой автоматически;
     *        после строчной  (а ) - печатает машинистка, он заканчивает слово.
     *
     * Пометки в комментариях:
     *   [ДОРАБОТКА 1] - поддержка двойной фамилии через дефис (основное задание);
     *   [ДОРАБОТКА 2] - универсальный шаблон (дополнительное задание);
     *   [ИСПРАВЛЕНО]  - исправлены недочёты базового образца.
     */
    public class Editor
    {
        public string Pattern = "Аа А.А.";   // [ДОРАБОТКА 2] шаблон; по умолчанию - формат исходной системы
        public string Text = "";             // текст строки ввода
        public int SelStart = 0;             // начало выделения (или позиция каретки)
        public int SelLength = 0;            // длина выделения
        public ObservableCollection<string> Output = new ObservableCollection<string>();  // выход: готовые строки

        int step = 0;          // [ДОРАБОТКА 2] позиция шаблона, до которой дошёл текст (вычисляет Parse)
        bool hyphen = false;   // [ДОРАБОТКА 1] в текущем слове уже есть дефис (вычисляет Parse)

        // Обработка одной нажатой клавиши. '\r' - Enter, '\b' - Backspace, остальное - символ.
        public void Press(char c)
        {
            // ---------- Enter: готовую строку - на выход ----------
            if (c == '\r')
            {
                if (IsComplete()) SaveAndClear();
                return;
            }

            // ---------- Выделена вся строка (готовая ФИО) ----------
            if (SelLength > 0 && SelLength == Text.Length)
            {
                if (c == '\b') { Clear(); return; }   // стереть всю строку
                if (!Char.IsLetter(c)) return;
                SaveAndClear();                       // буква - новая строка
            }

            int pos = SelStart;

            // ---------- Исправление буквы внутри текста ----------
            if (pos + SelLength < Text.Length)
            {
                // можно только заменить одну выделенную букву на другую букву
                if (SelLength == 1 && Char.IsLetter(Text[pos]) && Char.IsLetter(c))
                {
                    string before = Text.Substring(0, pos);
                    Parse(before);
                    if (step < Pattern.Length && SameAlphabet(c, Pattern[step]))
                    {
                        bool upper = Char.IsUpper(Pattern[step]) || before.EndsWith("-");
                        char letter = upper ? Char.ToUpper(c) : Char.ToLower(c);
                        Text = Text.Substring(0, pos) + letter + Text.Substring(pos + 1);
                        SelStart = pos + 1;
                        SelLength = 0;
                    }
                }
                return;
            }

            // ---------- [ИСПРАВЛЕНО] Backspace: стереть последний символ ----------
            if (c == '\b')
            {
                RemoveLast();
                // разделители, поставленные программой, стираем вместе с буквой перед ними
                Parse(Text);
                while (Text.Length > 0 && step < Pattern.Length && !Char.IsLetter(Pattern[step]))
                {
                    RemoveLast();
                    Parse(Text);
                }
                return;
            }

            // ---------- Обычный ввод в конец строки ----------
            AddAutoSeparators();                  // если шаблон начинается с разделителя
            Parse(Text);
            if (step >= Pattern.Length) return;   // строка уже готова

            char code = Pattern[step];                                          // что ждёт шаблон на n-ной позиции
            char next = step + 1 < Pattern.Length ? Pattern[step + 1] : '\0';   // что в шаблоне дальше
            char prev = Text.Length > 0 ? Text[Text.Length - 1] : '\0';         // последний символ строки

            if (Char.IsLetter(c) && SameAlphabet(c, code))
            {
                // [ДОРАБОТКА 2] регистр берётся из шаблона
                if (Char.IsUpper(code))
                    Append(Char.ToUpper(c).ToString());
                else if (prev == '-')                       // [ДОРАБОТКА 1] после дефиса - прописная
                    Append(Char.ToUpper(c).ToString());
                else                                        // [ИСПРАВЛЕНО] остальные буквы слова - строчные
                    Append(Char.ToLower(c).ToString());
            }
            else if (!Char.IsLetter(c) && Char.IsLower(code) && Char.IsLetter(prev))
            {
                if (c == '-' && next != '-' && !hyphen)
                    Append("-");                            // [ДОРАБОТКА 1] дефис двойной фамилии
                else if (c == next)
                    Append(c.ToString());                   // разделитель из шаблона - слово закончено
                else
                    return;                                 // другие знаки игнорируем
            }
            else
            {
                return;   // цифры, знаки, лишние пробелы, буквы другого алфавита - игнорируем
            }

            AddAutoSeparators();   // [ИСПРАВЛЕНО] точка ставится сразу, а не в KeyUp, как в образце

            // строка соответствует шаблону - выделяем для проверки (каретка остаётся справа)
            Parse(Text);
            if (step == Pattern.Length)
            {
                SelStart = 0;
                SelLength = Text.Length;
            }
        }

        // [ДОРАБОТКА 2] Пройти по введённому тексту и шаблону одновременно
        // и определить, какую позицию шаблона текст уже заполнил (step).
        private void Parse(string text)
        {
            step = 0;
            hyphen = false;
            foreach (char c in text)
            {
                if (step >= Pattern.Length) break;
                char code = Pattern[step];
                char next = step + 1 < Pattern.Length ? Pattern[step + 1] : '\0';

                if (Char.IsUpper(code))
                    step++;                              // прописная буква - один символ
                else if (Char.IsLower(code))
                {
                    if (Char.IsLetter(c)) { }            // слово продолжается
                    else if (c == '-' && next != '-')
                        hyphen = true;                   // дефис внутри слова
                    else
                    {
                        step += 2;                       // разделитель закончил слово
                        hyphen = false;
                    }
                }
                else
                    step++;                              // разделитель шаблона
            }
        }

        // Дописать разделители, стоящие в шаблоне сразу за текущей позицией (точку после инициала)
        private void AddAutoSeparators()
        {
            Parse(Text);
            while (step < Pattern.Length && !Char.IsLetter(Pattern[step]))
            {
                Append(Pattern[step].ToString());
                step++;
            }
        }

        // Строка готова: шаблон пройден до конца
        // (или шаблон кончается словом "а", и последний символ - буква)
        public bool IsComplete()
        {
            Parse(Text);
            if (step == Pattern.Length) return true;
            return step == Pattern.Length - 1 && Char.IsLower(Pattern[step])
                   && Text.Length > 0 && Char.IsLetter(Text[Text.Length - 1]);
        }

        // Проверка шаблона: есть прописная буква, все буквы - кириллица или латиница
        public static bool PatternIsCorrect(string p)
        {
            bool hasUpper = false;
            foreach (char ch in p)
            {
                if (Char.IsLetter(ch) && Alphabet(ch) == 0) return false;
                if (Char.IsUpper(ch)) hasUpper = true;
            }
            return hasUpper;
        }

        // Алфавит буквы: 1 - кириллица, 2 - латиница, 0 - другое
        private static int Alphabet(char ch)
        {
            ch = Char.ToUpper(ch);
            if ((ch >= 'А' && ch <= 'Я') || ch == 'Ё') return 1;
            if (ch >= 'A' && ch <= 'Z') return 2;
            return 0;
        }

        private static bool SameAlphabet(char a, char b)
        {
            return Alphabet(a) != 0 && Alphabet(a) == Alphabet(b);
        }

        // Дописать текст в конец строки, каретку - в конец
        private void Append(string s)
        {
            Text += s;
            SelStart = Text.Length;
            SelLength = 0;
        }

        private void RemoveLast()
        {
            if (Text.Length > 0) Text = Text.Substring(0, Text.Length - 1);
            SelStart = Text.Length;
            SelLength = 0;
        }

        // Очистить строку ввода, каретка - в левый край
        public void Clear()
        {
            Text = "";
            SelStart = 0;
            SelLength = 0;
        }

        // Готовую строку - на выход, строку ввода - очистить
        private void SaveAndClear()
        {
            if (IsComplete()) Output.Add(Text);
            Clear();
        }
    }
}
