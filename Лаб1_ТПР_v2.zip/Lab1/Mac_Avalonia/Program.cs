using System;
using Avalonia;

namespace LabFio
{
    // Точка входа.
    //   dotnet run             - открыть окно программы
    //   dotnet run -- --test   - прогнать тесты в терминале (без окна)
    class Program
    {
        [STAThread]
        public static void Main(string[] args)
        {
            if (args.Length > 0 && args[0] == "--test")
            {
                foreach (string line in Tests.Run()) Console.WriteLine(line);
                return;
            }
            BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
        }

        public static AppBuilder BuildAvaloniaApp()
        {
            return AppBuilder.Configure<App>().UsePlatformDetect().LogToTrace();
        }
    }
}
