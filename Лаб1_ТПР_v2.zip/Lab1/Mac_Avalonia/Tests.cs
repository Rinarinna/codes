using System;
using System.Collections.Generic;

namespace LabFio
{
    /*
     * Автоматические тесты. Запуск: кнопка "Запустить тесты" в окне
     * или в терминале командой:  dotnet run -- --test
     * Каждый тест: создаём Editor с шаблоном, "печатаем" строку клавиш так,
     * как это делает машинистка (вызываем тот же метод Press, что и окно),
     * и сравниваем результат с ожидаемым.
     * В строках клавиш: \b - Backspace, \r - Enter.
     */
    public static class Tests
    {
        static List<string> results;
        static int passed, failed;

        public static List<string> Run()
        {
            results = new List<string>();
            passed = 0;
            failed = 0;

            results.Add("--- Базовый формат (исходная система) ---");
            Check("T01 Обычный ввод", "Аа А.А.", "иванов ип", "Иванов И.П.");
            Check("T02 Всё прописными", "Аа А.А.", "ИВАНОВ ИП", "Иванов И.П.");
            Check("T03 Смешанный регистр", "Аа А.А.", "иВаНоВ иП", "Иванов И.П.");
            Check("T04 Лишние пробелы", "Аа А.А.", "иванов    и   п", "Иванов И.П.");
            Check("T05 Пробел в начале", "Аа А.А.", "  иванов ип", "Иванов И.П.");
            Check("T06 Цифры игнорируются", "Аа А.А.", "ив4нов1 и2п", "Ивнов И.П.");
            Check("T07 Знаки препинания", "Аа А.А.", "иванов, и.п!", "Иванов И.П.");
            CheckSelected("T08 Готовая строка выделена", "Аа А.А.", "иванов ип");

            results.Add("--- Двойная фамилия (основное задание) ---");
            Check("T09 Двойная фамилия", "Аа А.А.", "новиков-прибой ас", "Новиков-Прибой А.С.");
            Check("T10 Двойная прописными", "Аа А.А.", "НОВИКОВ-ПРИБОЙ АС", "Новиков-Прибой А.С.");
            Check("T11 Дефис в начале", "Аа А.А.", "-иванов ип", "Иванов И.П.");
            Check("T12 Два дефиса подряд", "Аа А.А.", "иванов--петров ип", "Иванов-Петров И.П.");
            Check("T13 Второй дефис", "Аа А.А.", "иванов-петров-сидоров ип", "Иванов-Петровсидоров И.П.");
            Check("T14 Пробел после дефиса", "Аа А.А.", "иванов- петров ип", "Иванов-Петров И.П.");

            results.Add("--- Работа со строкой ---");
            CheckList("T15 Ввод списка", "Аа А.А.", "иванов ип" + "петров-водкин кс\r",
                      "Иванов И.П.; Петров-Водкин К.С.");
            Check("T16 Строка очищена после выхода", "Аа А.А.", "иванов ип\r", "");
            CheckList("T17 Enter на неполной строке", "Аа А.А.", "иванов и\r", "");
            Check("T18 Backspace", "Аа А.А.", "иванов и\b\bа п\bс", "Иванова С.");
            Check("T19 Backspace по выделению", "Аа А.А.", "иванов ип\b", "");
            CheckEdit("T20 Исправление инициала", "Аа А.А.", "иванов ип", 7, 'с', "Иванов С.П.");
            CheckEdit("T21 Исправление в фамилии", "Аа А.А.", "иванов ип", 2, 'Х', "Ивхнов И.П.");

            results.Add("--- Произвольный шаблон (дополнительное задание) ---");
            CheckList("T22 Инициалы впереди", "А.А. Аа", "ипиванов\r", "И.П. Иванов");
            CheckList("T23 Полное ФИО", "Аа Аа Аа", "иванов иван иванович\r", "Иванов Иван Иванович");
            CheckList("T24 Неполное ФИО", "Аа Аа Аа", "иванов иван\r", "");
            Check("T25 Дефис в шаблоне", "Аа-Аа А.", "салтыков-щедрин м", "Салтыков-Щедрин М.");
            CheckList("T26 Запятая в шаблоне", "Аа, Аа", "пушкин, александр\r", "Пушкин, Александр");

            results.Add("--- Алфавит ---");
            Check("T27 Латиница при кир. шаблоне", "Аа А.А.", "ivanov иванов ип", "Иванов И.П.");
            Check("T28 Латинский шаблон", "Aa A.A.", "smith jr", "Smith J.R.");
            Check("T29 Кириллица при лат. шаблоне", "Aa A.", "смит smith j", "Smith J.");
            CheckList("T30 Порядок алфавитов", "Аа Aa", "ivanov иванов ivanov\r", "Иванов Ivanov");
            Check("T31 Буква Ё", "Аа А.А.", "ёжиков ёп", "Ёжиков Ё.П.");

            results.Add("--- Проверка шаблона ---");
            Report("T32 Шаблон без прописных", Editor.PatternIsCorrect("аа а.а.") ? "принят" : "отклонён", "отклонён");
            Report("T33 Пустой шаблон", Editor.PatternIsCorrect("") ? "принят" : "отклонён", "отклонён");
            Report("T34 Корректный шаблон", Editor.PatternIsCorrect("Аа А.А.") ? "принят" : "отклонён", "принят");

            results.Add("ИТОГО: пройдено " + passed + " из " + (passed + failed));
            return results;
        }

        // Создать редактор с шаблоном и "напечатать" клавиши
        static Editor Type(string pattern, string keys)
        {
            Editor ed = new Editor();
            ed.Pattern = pattern;
            foreach (char c in keys) ed.Press(c);
            return ed;
        }

        // Проверка содержимого строки ввода
        static void Check(string name, string pattern, string keys, string expected)
        {
            Editor ed = Type(pattern, keys);
            Report(name, ed.Text, expected);
        }

        // Проверка того, что ушло на выход
        static void CheckList(string name, string pattern, string keys, string expected)
        {
            Editor ed = Type(pattern, keys);
            Report(name, string.Join("; ", ed.Output), expected);
        }

        // Проверка исправления: выделить одну букву и напечатать другую
        static void CheckEdit(string name, string pattern, string keys, int position, char letter, string expected)
        {
            Editor ed = Type(pattern, keys);
            ed.SelStart = position;
            ed.SelLength = 1;
            ed.Press(letter);
            Report(name, ed.Text, expected);
        }

        // Проверка, что готовая строка выделена целиком
        static void CheckSelected(string name, string pattern, string keys)
        {
            Editor ed = Type(pattern, keys);
            bool selected = ed.SelStart == 0 && ed.SelLength == ed.Text.Length && ed.Text.Length > 0;
            Report(name, selected ? "выделена" : "не выделена", "выделена");
        }

        static void Report(string name, string actual, string expected)
        {
            if (actual == expected)
            {
                passed++;
                results.Add("OK    " + name + ":  \"" + actual + "\"");
            }
            else
            {
                failed++;
                results.Add("FAIL  " + name + ":  \"" + actual + "\", ожидалось \"" + expected + "\"");
            }
        }
    }
}
