using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;

namespace LabFio
{
    /*
     * Главное окно. Здесь только элементы окна и ОБРАБОТЧИКИ СОБЫТИЙ КЛАВИАТУРЫ.
     * Вся логика редактирования - в классе Editor.
     *
     * Обработчики подписаны в режиме Tunnel ("туннель"): они срабатывают РАНЬШЕ,
     * чем TextBox сам обработает клавишу. Поставив e.Handled = true, мы запрещаем
     * TextBox вставлять символ сам - текст строки формирует Editor.
     */
    public class MainWindow : Window
    {
        Editor editor = new Editor();

        TextBox textBox1;   // рабочая строка ввода
        TextBox textBox2;   // строка шаблона
        TextBlock label2;   // подсказка с текущим шаблоном / сообщение об ошибке
        ListBox listBox1;   // выход: введённый список
        ListBox listBox2;   // результаты тестов

        public MainWindow()
        {
            Title = "Ввод списка по шаблону";
            Width = 1000;
            Height = 560;

            // ----- создание элементов окна -----
            textBox2 = new TextBox { Text = editor.Pattern, Width = 280, FontSize = 16 };
            Button button1 = new Button { Content = "Применить шаблон", Margin = new Thickness(8, 0, 0, 0) };
            label2 = new TextBlock { Margin = new Thickness(0, 12, 0, 4) };
            textBox1 = new TextBox { FontSize = 20 };
            textBox1.ContextFlyout = null;   // убрать меню "Вставить", чтобы нельзя было вставить текст в обход проверок
            listBox1 = new ListBox { Height = 330, ItemsSource = editor.Output };
            Button button2 = new Button { Content = "Запустить тесты" };
            listBox2 = new ListBox { Height = 450, FontSize = 12, Margin = new Thickness(0, 8, 0, 0) };

            StackPanel templateRow = new StackPanel { Orientation = Orientation.Horizontal };
            templateRow.Children.Add(textBox2);
            templateRow.Children.Add(button1);

            StackPanel left = new StackPanel { Margin = new Thickness(12) };
            left.Children.Add(new TextBlock { Text = "Шаблон (Enter - применить):", Margin = new Thickness(0, 0, 0, 4) });
            left.Children.Add(templateRow);
            left.Children.Add(label2);
            left.Children.Add(textBox1);
            left.Children.Add(new TextBlock { Text = "Выход (введённый список):", Margin = new Thickness(0, 12, 0, 4) });
            left.Children.Add(listBox1);

            StackPanel right = new StackPanel { Margin = new Thickness(12) };
            right.Children.Add(button2);
            right.Children.Add(listBox2);

            Grid grid = new Grid { ColumnDefinitions = new ColumnDefinitions("*,*") };
            Grid.SetColumn(right, 1);
            grid.Children.Add(left);
            grid.Children.Add(right);
            Content = grid;

            // ----- подписка на события -----
            textBox1.AddHandler(TextInputEvent, new EventHandler<TextInputEventArgs>(TextBox1_TextInput), RoutingStrategies.Tunnel);
            textBox1.AddHandler(KeyDownEvent, new EventHandler<KeyEventArgs>(TextBox1_KeyDown), RoutingStrategies.Tunnel);
            textBox2.AddHandler(KeyDownEvent, new EventHandler<KeyEventArgs>(TextBox2_KeyDown), RoutingStrategies.Tunnel);
            button1.Click += Button1_Click;
            button2.Click += Button2_Click;

            ShowHint();
        }

        // ============ Рабочая строка: ввод символов (буквы, пробел, дефис, знаки) ============
        private void TextBox1_TextInput(object sender, TextInputEventArgs e)
        {
            e.Handled = true;   // TextBox сам символ не вставляет
            if (string.IsNullOrEmpty(e.Text)) return;
            foreach (char c in e.Text) Press(c);
        }

        // ============ Рабочая строка: служебные клавиши ============
        private void TextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            bool cmd = (e.KeyModifiers & (KeyModifiers.Control | KeyModifiers.Meta)) != 0;   // Ctrl или Cmd

            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                Press('\r');
            }
            else if (e.Key == Key.Back)
            {
                e.Handled = true;
                Press('\b');
            }
            else if (e.Key == Key.Delete)
            {
                e.Handled = true;   // удаление в середине строки запрещено
            }
            else if (cmd && (e.Key == Key.V || e.Key == Key.X || e.Key == Key.Z || e.Key == Key.Y))
            {
                e.Handled = true;   // запрет вставки, вырезания и отмены в обход проверок
            }
            // стрелки, выделение мышью и Shift+стрелками работают как обычно
        }

        // Передать клавишу в Editor и показать результат
        private void Press(char c)
        {
            // из окна - в Editor: текущий текст и выделение
            editor.Text = textBox1.Text ?? "";
            int a = textBox1.SelectionStart;
            int b = textBox1.SelectionEnd;
            if (a == b) a = b = textBox1.CaretIndex;   // нет выделения - берём позицию каретки
            editor.SelStart = Math.Min(a, b);
            editor.SelLength = Math.Abs(b - a);

            editor.Press(c);

            ShowState();
        }

        // Из Editor - в окно: текст и выделение (каретка - справа от выделения)
        private void ShowState()
        {
            int end = editor.SelStart + editor.SelLength;
            textBox1.Text = editor.Text;
            textBox1.CaretIndex = end;
            textBox1.SelectionStart = editor.SelStart;
            textBox1.SelectionEnd = end;
        }

        // ============ Строка шаблона ============
        private void TextBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                ApplyPattern();
            }
        }

        private void Button1_Click(object sender, RoutedEventArgs e)   // "Применить шаблон"
        {
            ApplyPattern();
        }

        private void ApplyPattern()
        {
            string p = textBox2.Text ?? "";
            if (Editor.PatternIsCorrect(p))
            {
                editor.Pattern = p;
                editor.Clear();
                ShowState();
                ShowHint();
                textBox1.Focus();
            }
            else
            {
                label2.Foreground = Brushes.Red;
                label2.Text = "Ошибка: в шаблоне нужна прописная буква, все буквы - кириллица или латиница";
            }
        }

        private void ShowHint()
        {
            label2.ClearValue(TextBlock.ForegroundProperty);
            label2.Text = "Текущий шаблон: " + editor.Pattern + "    Enter - на выход, Backspace - стереть";
        }

        // ============ Тесты ============
        private void Button2_Click(object sender, RoutedEventArgs e)   // "Запустить тесты"
        {
            listBox2.ItemsSource = Tests.Run();
        }
    }
}
