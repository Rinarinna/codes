using System;
using System.Windows.Forms;

namespace csWinFkey
{
    // Точка входа: запускает окно Form1
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
