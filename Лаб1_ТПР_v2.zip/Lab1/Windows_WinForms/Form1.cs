using System;
using System.Windows.Forms;

namespace csWinFkey
{
    /*
     * Лабораторная работа №1. Автоматизация ввода списков «на лету» по шаблону.
     *
     * Машинистка печатает как удобно: без точек, в любом регистре, с лишними пробелами.
     * Программа сама приводит строку к формату, который задан ШАБЛОНОМ:
     *   шаблон "Аа А.А.":  "новиков-прибой ас"  ->  "Новиков-Прибой А.С."
     *
     * Шаблон вводится в отдельной строке (вверху окна) и применяется по Enter или кнопкой.
     * Кодирование шаблона (анализируется n-ная позиция шаблона):
     *   прописная буква (А)  - одна прописная буква;
     *   строчная буква  (а)  - остальные буквы слова, строчные, сколько угодно.
     *                          В слове допускается ОДИН дефис (двойная фамилия),
     *                          буква после дефиса - прописная;
     *   алфавит буквы шаблона (кириллица / латиница) задаёт алфавит вводимых букв
     *                          на этой позиции; буквы другого алфавита игнорируются;
     *   любой другой символ  - разделитель:
     *        после прописной (А.) - ставится программой автоматически;
     *        после строчной  (а ) - печатает машинистка, он заканчивает слово.
     *
     * Работа со строкой ввода:
     *   - когда строка соответствует шаблону, она выделяется (можно проверить глазами);
     *   - следующая буква или Enter отправляет её в список (на выход),
     *     строка очищается, каретка - в левый край;
     *   - Backspace стирает последний символ;
     *   - ошибочную букву в середине можно выделить мышью и напечатать правильную.
     *
     * Пометки в комментариях:
     *   [ДОРАБОТКА 1] - поддержка двойной фамилии через дефис (основное задание);
     *   [ДОРАБОТКА 2] - универсальный шаблон (дополнительное задание);
     *   [ИСПРАВЛЕНО]  - исправлены недочёты базового образца.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox2.Text = "Аа А.А.";   // шаблон по умолчанию - формат исходной системы
            pattern = textBox2.Text;
            ShowHint();
        }

        string pattern = "";   // [ДОРАБОТКА 2] текущий шаблон
        int step = 0;          // [ДОРАБОТКА 2] позиция в шаблоне, до которой дошёл текст (вычисляет Parse)
        bool hyphen = false;   // [ДОРАБОТКА 1] в текущем слове уже есть дефис (вычисляет Parse)

        // =================== Строка ввода шаблона ===================

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')   // Enter - применить шаблон
            {
                e.Handled = true;
                ApplyPattern();
            }
        }

        private void button1_Click(object sender, EventArgs e)   // кнопка "Применить шаблон"
        {
            ApplyPattern();
        }

        private void ApplyPattern()
        {
            if (PatternIsCorrect(textBox2.Text))
            {
                pattern = textBox2.Text;
                textBox1.Clear();
                ShowHint();
                textBox1.Focus();
            }
            else
            {
                MessageBox.Show("Шаблон должен содержать хотя бы одну прописную букву, " +
                                "а все буквы - быть кириллицей или латиницей. Например: Аа А.А.");
            }
        }

        // =================== Рабочая строка ввода ===================

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            e.Handled = true;   // [ИСПРАВЛЕНО] символы вставляем сами, чтобы полностью контролировать строку

            // ---------- Enter: готовую строку - на выход ----------
            if (c == '\r')
            {
                if (IsComplete()) SaveAndClear();
                return;
            }

            // ---------- Выделена вся строка (готовая ФИО) ----------
            if (textBox1.SelectionLength > 0 && textBox1.SelectionLength == textBox1.Text.Length)
            {
                if (c == '\b') { textBox1.Clear(); return; }   // стереть всю строку
                if (!Char.IsLetter(c)) return;
                SaveAndClear();                                // буква - новая строка
            }

            int pos = textBox1.SelectionStart;

            // ---------- Исправление буквы внутри текста ----------
            if (pos + textBox1.SelectionLength < textBox1.Text.Length)
            {
                // можно только заменить одну выделенную букву на другую букву
                if (textBox1.SelectionLength == 1 && Char.IsLetter(textBox1.Text[pos]) && Char.IsLetter(c))
                {
                    string before = textBox1.Text.Substring(0, pos);
                    Parse(before);
                    if (step < pattern.Length && SameAlphabet(c, pattern[step]))
                    {
                        bool upper = Char.IsUpper(pattern[step]) || before.EndsWith("-");
                        e.KeyChar = upper ? Char.ToUpper(c) : Char.ToLower(c);
                        e.Handled = false;   // TextBox сам заменит выделенную букву
                    }
                }
                return;
            }

            // ---------- [ИСПРАВЛЕНО] Backspace: стереть последний символ ----------
            if (c == '\b')
            {
                RemoveLast();
                // разделители, поставленные программой, стираем вместе с буквой перед ними
                Parse(textBox1.Text);
                while (textBox1.Text.Length > 0 && step < pattern.Length && !Char.IsLetter(pattern[step]))
                {
                    RemoveLast();
                    Parse(textBox1.Text);
                }
                return;
            }

            // ---------- Обычный ввод в конец строки ----------
            AddAutoSeparators();                  // если шаблон начинается с разделителя
            Parse(textBox1.Text);
            if (step >= pattern.Length) return;   // строка уже готова

            char code = pattern[step];                                          // что ждёт шаблон на n-ной позиции
            char next = step + 1 < pattern.Length ? pattern[step + 1] : '\0';   // что в шаблоне дальше
            string text = textBox1.Text;
            char prev = text.Length > 0 ? text[text.Length - 1] : '\0';         // последний символ строки

            if (Char.IsLetter(c) && SameAlphabet(c, code))
            {
                // [ДОРАБОТКА 2] регистр берётся из шаблона
                if (Char.IsUpper(code))
                    textBox1.AppendText(Char.ToUpper(c).ToString());
                else if (prev == '-')                       // [ДОРАБОТКА 1] после дефиса - прописная
                    textBox1.AppendText(Char.ToUpper(c).ToString());
                else                                        // [ИСПРАВЛЕНО] остальные буквы слова - строчные
                    textBox1.AppendText(Char.ToLower(c).ToString());
            }
            else if (!Char.IsLetter(c) && Char.IsLower(code) && Char.IsLetter(prev))
            {
                if (c == '-' && next != '-' && !hyphen)
                    textBox1.AppendText("-");               // [ДОРАБОТКА 1] дефис двойной фамилии
                else if (c == next)
                    textBox1.AppendText(c.ToString());      // разделитель из шаблона - слово закончено
                else
                    return;                                 // другие знаки игнорируем
            }
            else
            {
                return;   // цифры, знаки, лишние пробелы, буквы другого алфавита - игнорируем
            }

            AddAutoSeparators();   // [ИСПРАВЛЕНО] точки ставятся здесь, а не в KeyUp

            // строка соответствует шаблону - выделяем для проверки
            Parse(textBox1.Text);
            if (step == pattern.Length)
            {
                textBox1.SelectionStart = 0;
                textBox1.SelectionLength = textBox1.Text.Length;
            }
        }

        // [ДОРАБОТКА 2] Пройти по введённому тексту и шаблону одновременно
        // и определить, какую позицию шаблона текст уже заполнил (step).
        private void Parse(string text)
        {
            step = 0;
            hyphen = false;
            foreach (char c in text)
            {
                if (step >= pattern.Length) break;
                char code = pattern[step];
                char next = step + 1 < pattern.Length ? pattern[step + 1] : '\0';

                if (Char.IsUpper(code))
                    step++;                              // прописная буква - один символ
                else if (Char.IsLower(code))
                {
                    if (Char.IsLetter(c)) { }            // слово продолжается
                    else if (c == '-' && next != '-')
                        hyphen = true;                   // дефис внутри слова
                    else
                    {
                        step += 2;                       // разделитель закончил слово
                        hyphen = false;
                    }
                }
                else
                    step++;                              // разделитель шаблона
            }
        }

        // Дописать разделители, стоящие в шаблоне сразу за текущей позицией (точку после инициала)
        private void AddAutoSeparators()
        {
            Parse(textBox1.Text);
            while (step < pattern.Length && !Char.IsLetter(pattern[step]))
            {
                textBox1.AppendText(pattern[step].ToString());
                step++;
            }
        }

        // Строка готова: шаблон пройден до конца
        // (или шаблон кончается словом "а", и последний символ - буква)
        private bool IsComplete()
        {
            string text = textBox1.Text;
            Parse(text);
            if (step == pattern.Length) return true;
            return step == pattern.Length - 1 && Char.IsLower(pattern[step])
                   && text.Length > 0 && Char.IsLetter(text[text.Length - 1]);
        }

        // Проверка шаблона: есть прописная буква, все буквы - кириллица или латиница
        private bool PatternIsCorrect(string p)
        {
            bool hasUpper = false;
            foreach (char ch in p)
            {
                if (Char.IsLetter(ch) && Alphabet(ch) == 0) return false;
                if (Char.IsUpper(ch)) hasUpper = true;
            }
            return hasUpper;
        }

        // Алфавит буквы: 1 - кириллица, 2 - латиница, 0 - другое
        private int Alphabet(char ch)
        {
            ch = Char.ToUpper(ch);
            if ((ch >= 'А' && ch <= 'Я') || ch == 'Ё') return 1;
            if (ch >= 'A' && ch <= 'Z') return 2;
            return 0;
        }

        private bool SameAlphabet(char a, char b)
        {
            return Alphabet(a) != 0 && Alphabet(a) == Alphabet(b);
        }

        private void RemoveLast()
        {
            if (textBox1.Text.Length > 0)
            {
                textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
                textBox1.SelectionStart = textBox1.Text.Length;
            }
        }

        // Готовую строку - на выход (в список), строку ввода - очистить, каретка в левый край
        private void SaveAndClear()
        {
            if (IsComplete()) listBox1.Items.Add(textBox1.Text);
            textBox1.Clear();
        }

        private void ShowHint()
        {
            label2.Text = "Текущий шаблон: " + pattern + "    Enter - на выход, Backspace - стереть";
        }

        private void button2_Click(object sender, EventArgs e)   // кнопка "Запустить тесты"
        {
            RunTests();
        }
    }
}
