using System;
using System.Windows.Forms;

namespace csWinFkey
{
    /*
     * Автоматические тесты. Запускаются кнопкой "Запустить тесты".
     * Каждый тест: задаём шаблон, "печатаем" строку клавиш так, как это делает
     * машинистка (вызываем тот же обработчик textBox1_KeyPress), и сравниваем
     * результат с ожидаемым. Результаты выводятся в правый список.
     * В строках клавиш: \b - Backspace, \r - Enter.
     */
    public partial class Form1
    {
        int passed, failed;

        private void RunTests()
        {
            string oldPattern = pattern;
            listBox2.Items.Clear();
            passed = 0;
            failed = 0;

            listBox2.Items.Add("--- Базовый формат (исходная система) ---");
            Check("T01 Обычный ввод", "Аа А.А.", "иванов ип", "Иванов И.П.");
            Check("T02 Всё прописными", "Аа А.А.", "ИВАНОВ ИП", "Иванов И.П.");
            Check("T03 Смешанный регистр", "Аа А.А.", "иВаНоВ иП", "Иванов И.П.");
            Check("T04 Лишние пробелы", "Аа А.А.", "иванов    и   п", "Иванов И.П.");
            Check("T05 Пробел в начале", "Аа А.А.", "  иванов ип", "Иванов И.П.");
            Check("T06 Цифры игнорируются", "Аа А.А.", "ив4нов1 и2п", "Ивнов И.П.");
            Check("T07 Знаки препинания", "Аа А.А.", "иванов, и.п!", "Иванов И.П.");
            CheckSelected("T08 Готовая строка выделена", "Аа А.А.", "иванов ип");

            listBox2.Items.Add("--- Двойная фамилия (основное задание) ---");
            Check("T09 Двойная фамилия", "Аа А.А.", "новиков-прибой ас", "Новиков-Прибой А.С.");
            Check("T10 Двойная прописными", "Аа А.А.", "НОВИКОВ-ПРИБОЙ АС", "Новиков-Прибой А.С.");
            Check("T11 Дефис в начале", "Аа А.А.", "-иванов ип", "Иванов И.П.");
            Check("T12 Два дефиса подряд", "Аа А.А.", "иванов--петров ип", "Иванов-Петров И.П.");
            Check("T13 Второй дефис", "Аа А.А.", "иванов-петров-сидоров ип", "Иванов-Петровсидоров И.П.");
            Check("T14 Пробел после дефиса", "Аа А.А.", "иванов- петров ип", "Иванов-Петров И.П.");

            listBox2.Items.Add("--- Работа со строкой ---");
            CheckList("T15 Ввод списка", "Аа А.А.", "иванов ип" + "петров-водкин кс\r",
                      "Иванов И.П.; Петров-Водкин К.С.");
            Check("T16 Строка очищена после выхода", "Аа А.А.", "иванов ип\r", "");
            CheckList("T17 Enter на неполной строке", "Аа А.А.", "иванов и\r", "");
            Check("T18 Backspace", "Аа А.А.", "иванов и\b\bа п\bс", "Иванова С.");
            Check("T19 Backspace по выделению", "Аа А.А.", "иванов ип\b", "");
            CheckEdit("T20 Исправление инициала", "Аа А.А.", "иванов ип", 7, 'с', "Иванов С.П.");
            CheckEdit("T21 Исправление в фамилии", "Аа А.А.", "иванов ип", 2, 'Х', "Ивхнов И.П.");

            listBox2.Items.Add("--- Произвольный шаблон (дополнительное задание) ---");
            CheckList("T22 Инициалы впереди", "А.А. Аа", "ипиванов\r", "И.П. Иванов");
            CheckList("T23 Полное ФИО", "Аа Аа Аа", "иванов иван иванович\r", "Иванов Иван Иванович");
            CheckList("T24 Неполное ФИО", "Аа Аа Аа", "иванов иван\r", "");
            Check("T25 Дефис в шаблоне", "Аа-Аа А.", "салтыков-щедрин м", "Салтыков-Щедрин М.");
            CheckList("T26 Запятая в шаблоне", "Аа, Аа", "пушкин, александр\r", "Пушкин, Александр");

            listBox2.Items.Add("--- Алфавит ---");
            Check("T27 Латиница при кир. шаблоне", "Аа А.А.", "ivanov иванов ип", "Иванов И.П.");
            Check("T28 Латинский шаблон", "Aa A.A.", "smith jr", "Smith J.R.");
            Check("T29 Кириллица при лат. шаблоне", "Aa A.", "смит smith j", "Smith J.");
            CheckList("T30 Порядок алфавитов", "Аа Aa", "ivanov иванов ivanov\r", "Иванов Ivanov");
            Check("T31 Буква Ё", "Аа А.А.", "ёжиков ёп", "Ёжиков Ё.П.");

            listBox2.Items.Add("--- Проверка шаблона ---");
            Report("T32 Шаблон без прописных", PatternIsCorrect("аа а.а.") ? "принят" : "отклонён", "отклонён");
            Report("T33 Пустой шаблон", PatternIsCorrect("") ? "принят" : "отклонён", "отклонён");
            Report("T34 Корректный шаблон", PatternIsCorrect("Аа А.А.") ? "принят" : "отклонён", "принят");

            listBox2.Items.Add("ИТОГО: пройдено " + passed + " из " + (passed + failed));

            // вернуть окно в рабочее состояние
            pattern = oldPattern;
            textBox2.Text = oldPattern;
            textBox1.Clear();
            listBox1.Items.Clear();
            ShowHint();
        }

        // Подготовка: задать шаблон, очистить строку ввода и список
        private void Prepare(string p)
        {
            pattern = p;
            textBox1.Clear();
            listBox1.Items.Clear();
        }

        // "Напечатать" клавиши: вызываем тот же обработчик, что и при реальном вводе
        private void Type(string keys)
        {
            foreach (char c in keys)
            {
                KeyPressEventArgs e = new KeyPressEventArgs(c);
                textBox1_KeyPress(textBox1, e);
                if (!e.Handled)   // обработчик разрешил стандартную вставку
                    textBox1.SelectedText = e.KeyChar.ToString();
            }
        }

        // Проверка содержимого строки ввода
        private void Check(string name, string p, string keys, string expected)
        {
            Prepare(p);
            Type(keys);
            Report(name, textBox1.Text, expected);
        }

        // Проверка того, что ушло на выход (в список)
        private void CheckList(string name, string p, string keys, string expected)
        {
            Prepare(p);
            Type(keys);
            string actual = "";
            foreach (object item in listBox1.Items)
                actual += (actual == "" ? "" : "; ") + item.ToString();
            Report(name, actual, expected);
        }

        // Проверка исправления: выделить одну букву и напечатать другую
        private void CheckEdit(string name, string p, string keys, int position, char letter, string expected)
        {
            Prepare(p);
            Type(keys);
            textBox1.SelectionStart = position;
            textBox1.SelectionLength = 1;
            Type(letter.ToString());
            Report(name, textBox1.Text, expected);
        }

        // Проверка, что готовая строка выделена целиком
        private void CheckSelected(string name, string p, string keys)
        {
            Prepare(p);
            Type(keys);
            bool selected = textBox1.SelectionStart == 0 && textBox1.SelectionLength == textBox1.Text.Length
                            && textBox1.Text.Length > 0;
            Report(name, selected ? "выделена" : "не выделена", "выделена");
        }

        private void Report(string name, string actual, string expected)
        {
            if (actual == expected)
            {
                passed++;
                listBox2.Items.Add("OK    " + name + ":  \"" + actual + "\"");
            }
            else
            {
                failed++;
                listBox2.Items.Add("FAIL  " + name + ":  \"" + actual + "\", ожидалось \"" + expected + "\"");
            }
        }
    }
}
